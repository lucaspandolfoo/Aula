<!DOCTYPE html>
<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();   
?>

<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>Sistema de Cadastro</title>
		<meta name="description" content="Responsive Retina-Friendly Menu with different, size-dependent layouts" />
		<meta name="keywords" content="responsive menu, retina-ready, icon font, media queries, css3, transition, mobile" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico"> 
		<link rel="stylesheet" type="text/css" href="css/default.css" />
		<link rel="stylesheet" type="text/css" href="css/component.css" />
		<link rel="stylesheet" type="text/css" href="fonts/style.css" />
		
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<!-- <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css"> -->
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
      <link rel="stylesheet" href="css/botoes.css">
<script src="js/modernizr.custom.js"></script>
	</head>
	<body>

		<div class="container">	

			<!-- Codrops top bar -->
			<div class="codrops-top clearfix">
				<span class="right"><a class="codrops-icon codrops-icon-drop" href="index.php"><span>Sistema de Cadastro</span></a></span>
				<span class="left"><a class="codrops-icon codrops-icon-drop" href="login/telaLogin.php"><span>Sair</span></a></span>
			</div>
			
			<div style="margin-bottom: -20px" class="main clearfix">
				<nav class="nav">					
					<ul>
						<li>
							<a href="index.php">
								<span class="icon">
									<i aria-hidden="true" class="icon-home"></i>
								</span>
								<span>Home</span>
							</a>
						</li>
						<li>
							<a href="equipamentos.php">
								<span class="icon"> 
									<i aria-hidden="true" class="icon-services"></i>
								</span>
								<span>Equipamentos</span>
							</a>
						</li>
						<li>
							<a href="tiposEquipamentos.php">
								<span class="icon">
									<i aria-hidden="true" class="icon-portfolio"></i>
								</span>
								<span>Tipos Equipamentos</span>
							</a>
						</li>
						<li>
							<a href="setores.php">
								<span class="icon">
									<i aria-hidden="true" class="icon-blog"></i>
								</span>
								<span>Setores</span>
							</a>
						</li>
						<li>
							<a href="usuarios.php">
								<span class="icon">
									<i aria-hidden="true" class="icon-team"></i>
								</span>
								<span>Usuários</span>
							</a>
						</li>
						<li>
							<a href="contato/contato.php">
								<span class="icon">
									<i aria-hidden="true" class="icon-contact"></i>
								</span>
								<span>Contato</span>
							</a>
						</li>
					</ul>
				</nav>
				
			</div>

			<header>
				<h1 style="margin-top:-30px" >Sistema de Cadastro de Equipamentos</h1>	
			</header>
			
		<div style="margin-top:-30px" class="limiter">
		<form action="adicionarEquipamentoUsuario.php" method="post" name="frmAdicionar" onsubmit="return validarAdicionar()">
		<div class="container-table100">
				<!-- Preenche o Equipamento -->
	        	<p style="color:white;font-size: 18px"> Equipamento </br>
				<select style="width:150px;margin-right:40px;height:30px;margin-top:5px" name="equipamento">
				<?php
				$sql = $PDO->prepare("SELECT * FROM equipamento");
				$sql->execute();
				$dados = $sql->fetchAll();
				
				foreach ($dados as $d) { ?>
				<option value="<?php echo $d["id_equip"]; ?>"><?php echo $d["nome"]; ?>
				</option> <?php  } ?>
				</select>
				</p>
				
				<!-- Preenche o Usuário -->
				<p style="color:white;font-size: 18px"> Usuário </br>
				<select style="width:150px;margin-right:40px;height:30px;margin-top:5px" name="usuario">
				<?php
				$sql = $PDO->prepare("SELECT * FROM usuario");
				$sql->execute();
				$dados = $sql->fetchAll();
				
				foreach ($dados as $d) { ?>
				<option value="<?php echo $d["id_user"]; ?>"><?php echo $d["nome"]; ?>
				</option> <?php } ?>
				</select>
				</p>
				
				<!-- Preenche o Setor -->
				<p style="color:white;font-size: 18px"> Setor </br>
				<select style="width:150px;margin-right:40px;height:30px;margin-top:5px" name="setor">
				<?php
				$sql = $PDO->prepare("SELECT * FROM setor");
				$sql->execute();
				$dados = $sql->fetchAll();
				
				foreach ($dados as $d) { ?>
				<option value="<?php echo $d["id_setor"]; ?>"><?php echo $d["nome"]; ?>
				</option> <?php } ?>
				</select>
				</p>

			 <!-- Preenche o Status -->
				<p style="color:white;font-size: 18px"> Status </br>
				<select style="width:150px;margin-right:40px;height:30px;margin-top:5px" name="status">
				<option value="Novo">Novo</option>,
				<option value="Usado">Usado</option>
				<option value="Sucata">Sucata</option>
				</select>
				</p>
				
			 
			  <button style="margin-top: 20px" class="btn btn-red" >Adicionar</button></p>
			</form>	
			<div class="wrap-table100">
				<div style="margin-top:50px" class="table100">
					<table>
						<thead>
							<tr class="table100-head">
								<th class="column1">Código</th>
								<th class="column2">Equipamento</th>
								<th class="column3">Usuário</th>
								<th class="column4">Setor</th>
								<th class="column5">Status</th>
								<th class="column6">Data Inclusão</th>
							</tr>
						</thead>
						<tbody>
						
								 <?php
								$sql = $PDO->prepare ("SELECT eu.*, s.nome nmsetor, u.nome nmuser, e.nome nmequip FROM equipamento_usuario eu, usuario u, setor s, equipamento e WHERE eu.setor_id = s.id_setor AND u.id_user = eu.usuario_id AND e.id_equip = eu.equipamento_id ORDER BY id");		
								$sql->execute();
								$dados = $sql->fetchAll();
								
								foreach ($dados as $d)
								  {
									  
									?>
								<tr>
									<td class="column1"><?=$d["id"]?></td>
									<td class="column2"><?=$d["nmequip"]?></td>
									<td class="column3"><?=$d["nmuser"]?></td>
									<td class="column4"><?=$d["nmsetor"]?></td>
									<td class="column5"><?=$d["status"]?></td>
									<td class="column6"><?= date("d/m/Y",strtotime($d["dtinclusao"]))?></td>
								</tr>
								<?php
			   
								  }
								  
								?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
		</div><!-- /container -->

		
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>



		<script>
			//  The function to change the class
			var changeClass = function (r,className1,className2) {
				var regex = new RegExp("(?:^|\\s+)" + className1 + "(?:\\s+|$)");
				if( regex.test(r.className) ) {
					r.className = r.className.replace(regex,' '+className2+' ');
			    }
			    else{
					r.className = r.className.replace(new RegExp("(?:^|\\s+)" + className2 + "(?:\\s+|$)"),' '+className1+' ');
			    }
			    return r.className;
			};	

			//  Creating our button in JS for smaller screens
			var menuElements = document.getElementById('menu');
			menuElements.insertAdjacentHTML('afterBegin','<button type="button" id="menutoggle" class="navtoogle" aria-hidden="true"><i aria-hidden="true" class="icon-menu"> </i> Menu</button>');

			//  Toggle the class on click to show / hide the menu
			document.getElementById('menutoggle').onclick = function() {
				changeClass(this, 'navtoogle active', 'navtoogle');
			}

			// http://tympanus.net/codrops/2013/05/08/responsive-retina-ready-menu/comment-page-2/#comment-438918
			document.onclick = function(e) {
				var mobileButton = document.getElementById('menutoggle'),
					buttonStyle =  mobileButton.currentStyle ? mobileButton.currentStyle.display : getComputedStyle(mobileButton, null).display;

				if(buttonStyle === 'block' && e.target !== mobileButton && new RegExp(' ' + 'active' + ' ').test(' ' + mobileButton.className + ' ')) {
					changeClass(mobileButton, 'navtoogle active', 'navtoogle');
				}
			}
		</script>
	</body>
</html>