<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();  

     $id = $_GET["id"];
	 $tipo = $_GET["tipo"];
	@$confirma = $_GET["confirma"];  
	
   if ( ($id) && ($confirma == 1) )
	   {
		 if ($tipo == "T") {  
		$sqlDelete = $PDO->prepare("DELETE FROM tipo_equipamento WHERE id_tpequip=?");
		$del = $sqlDelete->execute(array($id));
		header("Location: tiposEquipamentos.php");
		 }
		 else if ($tipo == "E") {  
		$sqlDelete = $PDO->prepare("DELETE FROM equipamento WHERE id_equip=?");
		$del = $sqlDelete->execute(array($id));
		header("Location: equipamentos.php");
		 }
		 else if ($tipo == "S") {  
		$sqlDelete = $PDO->prepare("DELETE FROM setor WHERE id_setor=?");
		$del = $sqlDelete->execute(array($id));
		header("Location: setores.php");
		 }
		 else if ($tipo == "U") {  
		$sqlDelete = $PDO->prepare("DELETE FROM usuario WHERE id_user=?");
		$del = $sqlDelete->execute(array($id));
		header("Location: usuarios.php");
		 }
	}

?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Remover</title>
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>	
			<div id="infoCabecalho"  class="grid-100 mobile-grid-100">
		    <h2> Remover </h2>
			</div>
	<div class="grid-container">

		
		<script>
		if (confirm("Deseja remover este registro?")) {
			window.location.href = "remover.php?id=<?=$id?>&confirma=1&tipo=<?=$tipo?>";
		} else {
			window.location.href = "index.php";
		}
			
	   </script>
	
	</body>
</html>