<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();   
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Equipamentos</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>   
  <!-- <div class="grid-100 grid-parent">
   <div style="background-color:blue" class="grid-50">
   <p style="margin-top:0px"> Equipamentos </p></button>
    </div>
   <div style="background-color:red" class="grid-50">
   <button class="btn btn-green" onclick="javascript:location.href='index.php';">Home</button>  
   </div>
 </div> -->
 
  <div class="page">
  
   <div id="inicio" class="grid-100">
   <p> Equipamentos
   <button class="btn btn-green" onclick="javascript:location.href='index.php';">Home</button></p>
 </div> 
			
  <span class="menu_toggle">
    <i class="menu_open fa fa-bars fa-lg"></i>
    <i class="menu_close fa fa-times fa-lg"></i>
  </span>
  <ul class="menu_items">
    <li><a href="frmAdicionarEquipamentos.php"><i class="icon fa fa-plus-circle fa-4x"></i> Inserir</a></li>
    <!--<li><a href="#"><i class="icon fa fa-coffee fa-2x"></i> Coffee</a></li> 
    <li><a href="#"><i class="icon fa fa-heart fa-2x"></i> Please</a></li> -->
  </ul>
  <main class="content">
    <div class="content_inner">
      <h1>Lista de Equipamentos</h1>

		   <div class="grid-100">
		   <form action="equipamentos.php" method="post"> Pesquisar por: <input type="search" name="nome"> 
		   <input type="submit" style= "color:#584E4A;font-weight:bold" value="OK">  <a id="limpar" href="equipamentos.php">Limpar Pesquisa</a>
		   </form> 
		   </div>
		   
		   <div class="grid-30"> &nbsp; </div>
		      
            <div class="grid-100">
			<table width="100%" border="1" bordercolor=black>
			<tr id="menuTabela">
			
			<th>Cód</th>
			<th>Nome</th>
			<th>Marca</th>
			<th>Modelo</th>
			<th>Tipo Equipamento</th>
			<th>Status</th>
			<th>Tempo Uso</th>
			<th>Garantia</th>
			<th>Editar</th>
			<th>Excluir</th>
			</tr>
			
			 <?php
			 @$nome = $_REQUEST["nome"];
			 if ($nome) {
			$sql = $PDO->prepare ("SELECT e.*, tp.nome nomeequip FROM equipamento e, tipo_equipamento tp WHERE tp.id_tpequip = e.tipo_equipamento_id AND e.nome LIKE '%$nome%' ORDER BY e.id_equip ");
			 }else{
		     $sql = $PDO->prepare ("SELECT e.*, tp.nome nomeequip FROM equipamento e, tipo_equipamento tp WHERE tp.id_tpequip = e.tipo_equipamento_id ORDER BY e.id_equip");
			 }				
			$sql->execute();
			$dados = $sql->fetchAll();
			
			foreach ($dados as $d)
			  {
				  
			  ?>
			   <tr>  
			   
			  <td><?=$d["id_equip"]?></td>
			  <td><?=$d["nome"]?></td>
			  <td><?=$d["marca"]?></td>
			  <td><?=$d["modelo"]?></td>
			  
			   <!-- AJUSTA TIPO DO EQUIPAMENTO -->
			  
			  <td><?=$d["nomeequip"]?></td>
			  <td><?=$d["status"]?></td>
			  <td><?=$d["tempo_uso"]?></td>
			  
			  <!-- AJUSTA TRUE OR FALSE -->
			  <?php if($d["garantia"]==true){ ?>
			  <td>Sim</td>
			  <?php } else { ?>
			  <td>Não</td>
			  <?php }
			  ?>


              <td><a style="color:#584E4A" href="frmEditarEquipamentos.php?id=<?=$d["id_equip"]?>">Editar</a></td>
			  <td><a style="color:#584E4A" href="remover.php?id=<?=$d["id_equip"]?>&tipo=<?="E"?>">Remover</a> </td>
			   
			   </tr>
			   <?php
			   
			  	  }
				  
			    ?>
			</table>
		   </div>
    </div>
  </main>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
