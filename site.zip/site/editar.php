<?php
 /* Require no script contendo a classe */  
 require_once 'conexao.php'; 
 
 /* Variável recebendo instância do objeto PDO */  
 $PDO = Conexao::getInstance();  


$nomeTela = "";
$telaPHP = "";
$tipo = $_GET["tipo"];
			
 if ($tipo == "S") {  
 
$id = $_POST["id"];
$nome = $_POST["nome"];

$sqlUpdate = $PDO->prepare("UPDATE setor SET nome=? WHERE id_setor=?");
$edit = $sqlUpdate->execute(array($nome,$id));
$nomeTela = "Setor";
$telaPHP = "setores.php";
 }
 
 else if ($tipo == "T") {  
 
$id = $_POST["id"];
$nome = $_POST["nome"];

$sqlUpdate = $PDO->prepare("UPDATE tipo_equipamento SET nome=? WHERE id_tpequip=?");
$edit = $sqlUpdate->execute(array($nome,$id));
$nomeTela = "Tipo de Equipamento";
$telaPHP = "tiposEquipamentos.php";
 }
 
 else if ($tipo == "E") {  
 
$id = $_POST["id"];
$nome = $_POST["nome"];
$marca = $_POST["marca"];
$modelo = $_POST["modelo"];
$tipoequipamento = $_POST["tipo_equipamento"];
$status = $_POST["status"];
$tempouso = $_POST["tempouso"];
$garantia = $_POST["garantia"];
$datainigarantia = date("Y-m-d", strtotime($_POST["dtinigarantia"])); 
$datafimgarantia = date("Y-m-d", strtotime($_POST["dtfimgarantia"])); 

$sqlUpdate = $PDO->prepare("UPDATE equipamento SET nome=?, marca=?, modelo=?, tipo_equipamento_id=?, status=?, tempo_uso=?, garantia=?, dt_inicio_garantia=?, dt_fim_garantia=? WHERE id_equip=?");
$edit = $sqlUpdate->execute(array($nome,$marca,$modelo,$tipoequipamento,$status,$tempouso,$garantia,$datainigarantia,$datafimgarantia,$id));
$nomeTela = "Equipamento";
$telaPHP = "equipamentos.php";
 }
 
 else if ($tipo == "U") {  
 
$id = $_POST["id"];
$nome = $_POST["nome"];
$login = $_POST["login"];
$senha = $_POST["senha"];
$email = $_POST["email"];
$status = $_POST["status"];

$sqlUpdate = $PDO->prepare("UPDATE usuario SET nome=?, login=?, senha=?, email=?, status=? WHERE id_user=?");
$edit = $sqlUpdate->execute(array($nome,$login,$senha,$email,$status,$id));
$nomeTela = "Usuário";
$telaPHP = "usuarios.php";
 }
 
 

?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Editar</title>
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>
    
	<body>
		<div id="infoCabecalho"  class="grid-100 mobile-grid-100">
		    <h2> Editar </h2>
			</div>
		<div class="grid-container">
			
			<div class="grid-container">
				<?php
               if($edit)  
			   {
			   ?>
			  <div class="grid-40">
		       <h2><?=$nomeTela?> alterado com sucesso </h2>
			   <p><a href="<?=$telaPHP?>"> Voltar</a></p>
			   </div>
			   <div class="grid-60">
			   <img style="margin-left:0;margin-top:10px" src="img/feliz.png" width="10%" alt="icone feliz">
			   </div>
			   <?php
	           }
			   else
			   {
			   ?>   
			   <div class="grid-container">
			   <div class="grid-35">
		      <h2>Erro ao alterar <?=$nomeTela?> </h2>
			  <p><a href="index.php"> Voltar</a></p>
			   </div>
			   
			   <div class="grid-65">
			   <img style="margin-left:0;margin-top:10px" src="img/triste.png" width="11%" alt="icone feliz">
			   </div>
			  <?php
			  var_dump($PDO->errorInfo());
			   }
               ?>
			   
			   </div>
	</div>	
	</body>
</html>