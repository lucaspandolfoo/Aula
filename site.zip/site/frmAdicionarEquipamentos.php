<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();  
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Cadastrar Equipamento</title>
		<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">

        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>
    
	<body>
			<div id="infoCabecalho"  class="grid-100 mobile-grid-100">
		    <h2> Cadastrar Equipamento </h2>
			</div>
			
		<div style="background-color:#f0f0f0" class="grid-container">

			
			<div class="grid-50">
				<h2>Informações do Equipamento: </h2>

				<form action="adicionarEquipamentos.php" method="post" name="frmAdicionar" onsubmit="return validarAdicionar()">
				
			    <p> Nome: <br> <input style="width:300px" type="text" name="nome" placeholder="Digite o Nome" autofocus="autofocus" maxlength="50"></p>
				<p> Marca: <br> <input  style="width:300px" type="text" name="marca" placeholder="Digite a Marca" maxlength="50"></p>
				<p> Modelo: <br> <input  style="width:200px" type="text" name="modelo" placeholder="Digite o Modelo" maxlength="50"></p>
				
				<p> Tipo Equipamento: </br>
				<select style="width:200px" name="tipo_equipamento">
				<?php
				$sql = $PDO->prepare("SELECT * FROM tipo_equipamento");
				$sql->execute();
				$dados = $sql->fetchAll();
				
				foreach ($dados as $d) { ?>
				<option value="<?php echo $d["id_tpequip"]; ?>"><?php echo $d["nome"]; ?>
				</option> <?php
				
				}
				
				?>
				</select>
				</p>
				
				<p> Status: <br> <input  style="width:200px" type="text" name="status" placeholder="Digite o Status" maxlength="20"></p>
				<p> Tempo Uso: <br> <input  style="width:60px" type="text" name="tempouso" placeholder="Tempo" maxlength="20"></p>
				
				<p><input type="submit" value="Enviar">
					<input type="reset" value="Limpar">
					<a style="text-decoration:none" href="index.php"><input type="button" value="Voltar"></a></p>
			</div>
			
			<div class="grid-50">
			<p style="margin-top:60px"> Garantia: <br>
			<select style="width:200px" name="garantia">
			<option value="true">Sim</option>
			<option value="false">Não</option>
			</select>
			<p> Data Início Garantia: <br> <input  style="width:200px" type="text" name="dtinigarantia" maxlength="20" class="form-control" placeholder="Ex.: dd/mm/aaaa" data-mask="00/00/0000" maxlength="10" autocomplete="off"></p>
			<p> Data Final Garantia <br> <input  style="width:200px" type="text" name="dtfimgarantia" maxlength="20" class="form-control" placeholder="Ex.: dd/mm/aaaa" data-mask="00/00/0000" maxlength="10" autocomplete="off"></p>
			
			
			
			</form>
		 </div>
			
		   
		 </div>
		 
		<script src="js/site.js"></script>
	    <script src="js/preencheDigitos.js"></script>		
		<script src="js/validaVirgula.js"></script>
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/jquery.mask.min.js"></script>
		<script src="js/locastyle.js"></script>
		<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
		<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
		<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>

	</body>
</html>