<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();  
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Cadastrar Setor</title>
		<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">

        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>
    
	<body>
			<div id="infoCabecalho"  class="grid-100 mobile-grid-100">
		    <h2> Cadastrar Setor</h2>
			</div>
			
		<div style="background-color:#f0f0f0" class="grid-container">

			
			<div class="grid-100">
				<h2>Informações do Setor:</h2>

				<form action="adicionarSetores.php" method="post" name="frmAdicionar" onsubmit="return validarAdicionar()">
				
			    <p> Nome: <br> <input style="width:300px" type="text" name="nome" placeholder="Nome do Setor" autofocus="autofocus" maxlength="50"></p>
				
				<p><input type="submit" value="Enviar">
					<input type="reset" value="Limpar">
					<a style="text-decoration:none" href="setores.php"><input type="button" value="Voltar"></a></p>
			</div>
			
			
			</form>
		   
		 </div>
		 
		<script src="js/site.js"></script>
	    <script src="js/preencheDigitos.js"></script>		
		<script src="js/validaVirgula.js"></script>
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/jquery.mask.min.js"></script>
		<script src="js/locastyle.js"></script>
		<script async="" src="//www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="//code.jquery.com/jquery-2.0.3.min.js"></script>
		<script type="text/javascript" src="//assets.locaweb.com.br/locastyle/2.0.6/javascripts/locastyle.js"></script>
		<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>

	</body>
</html>