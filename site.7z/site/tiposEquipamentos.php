<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();   
?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Tipos de Equipamentos</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  <link rel='stylesheet' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>   
  <!-- <div class="grid-100 grid-parent">
   <div style="background-color:blue" class="grid-50">
   <p style="margin-top:0px"> Equipamentos </p></button>
    </div>
   <div style="background-color:red" class="grid-50">
   <button class="btn btn-green" onclick="javascript:location.href='index.php';">Home</button>  
   </div>
 </div> -->
 
  <div class="page">
  
   <div id="inicio" class="grid-100">
   <p> Tipos de Equipamentos
   <button id="btnAzul" class="btn btn-green" onclick="javascript:location.href='index.php';">Home</button></p>
 </div> 
			
  <span id="botaoToggleAzul" class="menu_toggle">
    <i class="menu_open fa fa-bars fa-lg"></i>
    <i class="menu_close fa fa-times fa-lg"></i>
  </span>
  <ul class="menu_items">
    <li><a href="frmAdicionarTiposEquipamentos.php"><i class="icon fa fa-plus-circle fa-4x"></i> Inserir</a></li>
    <!--<li><a href="#"><i class="icon fa fa-coffee fa-2x"></i> Coffee</a></li> 
    <li><a href="#"><i class="icon fa fa-heart fa-2x"></i> Please</a></li> -->
  </ul>
  <main class="content">
    <div id="tpequip" class="content_inner">
      <h1>Lista de Tipos de Equipamentos</h1>

		   <div class="grid-100">
		   <form action="tiposEquipamentos.php" method="post"> Pesquisar por: <input type="search" name="nome"> 
		   <input type="submit" style= "color:#584E4A;font-weight:bold" value="OK">  <a id="limpar" href="tiposEquipamentos.php">Limpar Pesquisa</a>
		   </form> 
		   </div>
		   
		   <div class="grid-30"> &nbsp; </div>
		      
            <div class="grid-100">
			<table width="100%" border="1" bordercolor=black>
			<tr id="menuTabela">
			
			<th>Cód</th>
			<th>Nome</th>
			<th>Editar</th>
			<th>Excluir</th>
			</tr>
			
			 <?php
			 @$nome = $_REQUEST["nome"];
			 if ($nome) {
			$sql = $PDO->prepare ("SELECT * FROM tipo_equipamento WHERE nome LIKE '%$nome%' ORDER BY id_tpequip ");
			 }else{
		     $sql = $PDO->prepare ("SELECT * FROM tipo_equipamento ORDER BY id_tpequip");
			 }				
			$sql->execute();
			$dados = $sql->fetchAll();
			
			foreach ($dados as $d)
			  {
				  
			  ?>
			   <tr>  
			   
			  <td><?=$d["id_tpequip"]?></td>
			  <td><?=$d["nome"]?></td>
			  
			  
              <td><a style="color:#584E4A" href="frmEditarTiposEquipamentos.php?id=<?=$d["id_tpequip"]?>">Editar</a></td>
			  <td><a style="color:#584E4A" href="remover.php?id=<?=$d["id_tpequip"]?>&tipo=<?="T"?>">Remover</a> </td>
			  
			   
			   </tr>
			   <?php
			   
			  	  }
				  
			    ?>
			</table>
		   </div>
    </div>
  </main>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
