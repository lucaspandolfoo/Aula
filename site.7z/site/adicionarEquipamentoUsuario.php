<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();    

    $equipamento = $_POST["equipamento"];
	$usuario = $_POST["usuario"];
	$setor = $_POST["setor"];
	$status = $_POST["status"];
		
	
	$sqlInsert = $PDO->prepare ("INSERT INTO equipamento_usuario (equipamento_id, usuario_id, setor_id, status, dtinclusao) VALUES(?,?,?,?,?)");
	$add = $sqlInsert->execute(array($equipamento,$usuario,$setor,$status,"now()"));
	
?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Cadastro</title>
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>
    
	<body>
			<div id="infoCabecalho"  class="grid-100 mobile-grid-100">
		    <h2> Cadastro </h2>
			</div>
		<div class="grid-container">
			
				<?php
               if($add)  
			   {
		         ?>
				<div class="grid-100">
				<div class="grid-40">
		       <h2>Equipamento do Usuário inserido com sucesso</h2>
			  <p><a href="index.php"> Voltar</a></p>
			   </div>
			   <div class="grid-60">
			   <img style="margin-left:0;margin-top:10px" src="img/feliz.png" width="10%" alt="icone feliz">
			   </div>
			   </div>
			   <?php
	           }
			   else
			   {
			   ?>   
			  <div class="grid-100">
			   <div class="grid-35">
			   <h2>Erro ao inserir Equipamento do Usuário</h2>
			   <p><a href="index.php"> Voltar</a></p>
			   </div>
			   <div class="grid-65">
			   <img style="margin-left:0;margin-top:10px" src="img/triste.png" width="11%" alt="icone feliz">
			   </div>
			   <?php
			  var_dump($PDO->errorInfo());
			   }
               ?>
        </div>
     </div>			   
	</body>
</html>