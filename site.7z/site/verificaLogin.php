<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();  
 
// Recuperando os dados do formulário
$usuario = $_POST["LoginUsuario"];
$senha = $_POST["SenhaUsuario"];
$redireciona = "index.php";

$buscar = $PDO->prepare ("SELECT id_user, login, senha FROM usuario WHERE login =? AND senha =? AND status = true");
$buscar->execute(array($usuario,$senha));
$linha = $buscar->fetch(PDO::FETCH_ASSOC);


if($buscar->rowCount()){
	$_SESSION['id_user'] = $linha['id_user'];
	$_SESSION['usuario'] = $linha['usuario'];
	header("Location: ".$redireciona."");
	
	// Atualiza a tela
	echo "<meta HTTP-EQUIV='refresh' CONTENT=';URL=../index.php'>";

	exit;
	}else{
	 echo '<p style="font: 30px Verdana;  text-align:center; color:red;">Usuario ou senha inválidos.';
	echo '<meta http-equiv="refresh" content="1;URL=login/telaLogin.php" />';
	}

?>