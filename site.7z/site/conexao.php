<?php 

 /*  
  * Constantes de parâmetros para configuração da conexão  
  */  
 define('HOST', 'localhost');  
 define('DBNAME', 'cadastro');  
 define('CHARSET', 'utf8');  
 define('PORT', '5433');  
 define('USER', 'postgres');  
 define('PASSWORD', 'postgres');  
 
 class Conexao {  
 
   /*  
    * Atributo estático para instância do PDO  
    */  
   private static $pdo;
 
   /*  
    * Escondendo o construtor da classe  
    */ 
   private function __construct() {  
     //  
   } 
 
   /*  
    * Método estático para retornar uma conexão válida  
    * Verifica se já existe uma instância da conexão, caso não, configura uma nova conexão  
    */  
   public static function getInstance() {  
     if (!isset(self::$pdo)) {  
       try {  
         $opcoes = array(PDO::ATTR_PERSISTENT => TRUE);  
         self::$pdo = new PDO("pgsql:host=" . HOST . "; port=" . PORT . "; dbname=" . DBNAME . ";", USER, PASSWORD, $opcoes);  
       } catch (PDOException $e) {  
         print "Erro: " . $e->getMessage();  
       }  
     }  
     return self::$pdo;  
   }  
 }

 ?>

