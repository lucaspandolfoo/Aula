<?php
/* Require no script contendo a classe */  
require_once 'conexao.php'; 

/* Variável recebendo instância do objeto PDO */  
$PDO = Conexao::getInstance();    

?>

<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
		<meta name="viewport" content="width=device-width, user-scalable=no">
        <title>Sistema de Alunos</title>
        <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/unsemantic-grid-responsive-no-ie7.css">
        <link rel="stylesheet" href="css/estilo.css">
	</head>
    
	<body>
		<div class="grid-container">
			<div class="grid-30 mobile-grid-100">
				<a href="index.php"><img src="img/logo-horizontal.jpg" width="80%" alt="logotipo da univates"></a>
			</div>
			<div class="grid-70 mobile-grid-100">
				<h1>Site</h1>
			</div>
		   
		   <div id="menu" class="grid-100 grid-parent">
		   <div class="grid-15"><a href="index.php">Início</a></div>

		   <?php
				$dia = date("w");
				Switch ($dia)
				{
				Case 0: $dia2 = "Domingo";
				Break;
				Case 1: $dia2 = "Segunda-Feira";
				Break;
				Case 2: $dia2 = "Terça-Feira";
				Break;
				Case 3: $dia2 = "Quarta-Feira";
				Break;
				Case 4: $dia2 = "Quinta-Feira";
				Break;
				Case 5: $dia2 = "Sexta-Feira";
				Break;
				Case 6: $dia2 = "Sábado";
				Break;
                }       
               //echo ($dia2 . ", " . date("d/m/Y."));				
                ?>
		   <div id="data" class="grid-30"></div>
		   </div>
		   
		   <br>
		   
		    <div class="grid-100">
			<h1> Equipamentos </h1>
			</div>
		   
		   <div class="grid-30"> &nbsp; </div>
	  <div class="grid-100">
			<table width="100%" border="1" bordercolor=black>
			<tr id="menuTabela">
			
			<th>Cód</th>
			<th>Nome</th>
			<th>Marca</th>
			<th>Modelo</th>
			<th>Tipo Equipamento</th>
			<th>Status</th>
			<th>Tempo Uso</th>
			<th>Garantia</th>
			<th>Editar</th>
			<th>Excluir</th>
			</tr>
			
			 <?php
		    $sql = $PDO->prepare ("SELECT e.*, tp.nome nomeequip FROM equipamento e, tipo_equipamento tp WHERE tp.id_tpequip = e.tipo_equipamento_id ORDER BY e.id_equip");		
			$sql->execute();
			$dados = $sql->fetchAll();
			
			foreach ($dados as $d)
			  {
				  
			  ?>
			   <tr>  
			   
			  <td><?=$d["id_equip"]?></td>
			  <td><?=$d["nome"]?></td>
			  <td><?=$d["marca"]?></td>
			  <td><?=$d["modelo"]?></td>
			  
			   <!-- AJUSTA TIPO DO EQUIPAMENTO -->
			  
			  <td><?=$d["nomeequip"]?></td>
			  <td><?=$d["status"]?></td>
			  <td><?=$d["tempo_uso"]?></td>
			  
			  <!-- AJUSTA TRUE OR FALSE -->
			  <?php if($d["garantia"]==true){ ?>
			  <td>Sim</td>
			  <?php } else { ?>
			  <td>Não</td>
			  <?php }
			  ?>

              <td><a style="color:blue" href="frmEditar.php?id=<?=$d["id_equip"]?>">Editar</a></td>
			  <td><a style="color:blue" href="remover.php?id=<?=$d["id_equip"]?>">Remover</a> </td>
			   
			   </tr>
			   <?php
			   
			  	  }
				  
			    ?>
			</table>
		   </div>

		
		</div>
	</body>
</html>