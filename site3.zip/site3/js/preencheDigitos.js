// Função chamada ao sair do campo input
function mascara()
{
	//Pega o valor digitado no campo
	var campo = document.getElementById("n1").value;
	var campo2 = document.getElementById("n2").value;
    var campo3 = document.getElementById("n3").value;

	
	//VALIDA A DIGITAÇÃO DA NOTA 1
	if (campo > 10) {
		document.getElementById("n1").value = 10 + ".0";
		calcular();
	} else {
	
	if( campo.length == 2 || campo.length == 1){
	document.getElementById("n1").value = campo + ".0";
	}

	if(campo.indexOf(".")!=-1){
	if (campo.length == 2) {
	document.getElementById("n1").value = campo+ "0";
	}
	}
	}
	
	//VALIDA A DIGITAÇÃO DA NOTA 2
	if (campo2 > 10) {
		document.getElementById("n2").value = 10 + ".0";
		calcular();
	} else {
	
	if(campo2.length == 2 || campo2.length == 1){
	document.getElementById("n2").value = campo2 + ".0";
	}
	
	if(campo2.indexOf(".")!=-1){
	if (campo2.length == 2) {
	document.getElementById("n2").value = campo2+ "0";
	}
	}
	}
	
	//VALIDA A DIGITAÇÃO DA NOTA 3
	
	if (campo3 > 10) {
		document.getElementById("n3").value = 10 + ".0";
		calcular();
	} else {
	
	if(campo3.length == 2 || campo3.length == 1){
	document.getElementById("n3").value = campo3 + ".0";
	}
	
	if(campo3.indexOf(".")!=-1){
	if (campo3.length == 2) {
	document.getElementById("n3").value = campo3+ "0";
	}
	}
	}
	
	
/* Função para calcular a média das notas em tempo real */
function calcular(){
	var valor1 = parseFloat(document.getElementById('n1').value);
	var valor2 = parseFloat(document.getElementById('n2').value);
	var valor3 = parseFloat(document.getElementById('n3').value);
	
	if (document.frmAdicionar.nota1.value == '')  {
		valor1 = 0;
	 }
	if (document.frmAdicionar.nota2.value == '') {
		valor2 = 0;;
	 }
	 if (document.frmAdicionar.nota3.value == '') {
		valor3 = 0;
	 }
	 
   var result = (valor1 + valor2 + valor3) / 3;	
   document.getElementById('media').value = result.toFixed(1);
}
}