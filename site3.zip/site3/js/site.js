function validarAdicionar()
{
	if (document.frmAdicionar.nome.value == "")
	{
		alert("Nome não preenchido!");
		document.frmAdicionar.nome.focus();
		return false;
	}
	if (document.frmAdicionar.endereco.value == "")
	{
		alert("Endereço não preenchido!");
		document.frmAdicionar.endereco.focus();
		return false;
	}
	if (document.frmAdicionar.cidade.value == "")
	{
		alert("Cidade não preenchida!");
		document.frmAdicionar.cidade.focus();
		return false;
	}
	if (document.frmAdicionar.email.value == "" 
	|| document.frmAdicionar.email.value.indexOf('@')==-1
	|| document.frmAdicionar.email.value.indexOf('.')==-1)
	{
		alert("E-mail não preenchido ou incorreto!");
		document.frmAdicionar.email.focus();
		return false;
	}
	if (document.frmAdicionar.telefone.value == "")
	{
		alert("Telefone não preenchido!");
		document.frmAdicionar.telefone.focus();
		return false;
	} 
		if (document.frmAdicionar.obs.value == "")
	{
		alert("Observações não preenchidas!");
		document.frmAdicionar.obs.focus();
		return false;
	}
	if (document.frmAdicionar.nota1.value == "")
	{
		alert("Nota 1 não preenchida!");
		document.frmAdicionar.nota1.focus();
		return false;
	}
	if (document.frmAdicionar.nota2.value == "")
	{
		alert("Nota 2 não preenchida!");
		document.frmAdicionar.nota2.focus();
		return false;
	}
	if (document.frmAdicionar.nota3.value == "")
	{
		alert("Nota 3 não preenchida!");
		document.frmAdicionar.nota3.focus();
		return false;
	}
	return true;
}
