function ver(){
if(document.frmAdicionar.nota1.value.indexOf(",")!=-1){
alert("Digite a nota com um ponto(.) ao invés de usar vírgula (,)\nEx: 8.5");
document.frmAdicionar.nota1.value="";
}
if(document.frmAdicionar.nota2.value.indexOf(",")!=-1){
alert("Digite a nota com um ponto(.) ao invés de usar vírgula (,)\nEx: 8.5");
document.frmAdicionar.nota2.value="";
}
if(document.frmAdicionar.nota3.value.indexOf(",")!=-1){
alert("Digite a nota com um ponto(.) ao invés de usar vírgula (,)\nEx: 8.5");
document.frmAdicionar.nota3.value="";
}
}
	